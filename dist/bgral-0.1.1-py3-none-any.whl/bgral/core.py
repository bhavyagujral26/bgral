def made_by():
    return "Bhavya Gujral"

def check():
    return "yup its fine"
